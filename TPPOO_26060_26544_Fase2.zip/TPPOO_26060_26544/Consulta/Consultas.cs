﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 04-11-2023
 * 
 * File: Class Consulta
 *  
 */
using Pessoa;
using System.Runtime.Serialization.Formatters.Binary;

#pragma warning disable SYSLIB0011 //BinaryFormatter indicado como obsoleto, suprimir esse erro

public enum TipoConsulta
{
    Geral,
    Ortodentia,
    Exames
}

namespace Consulta
{
    [Serializable]
    public class Consultas
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Consulta
        /// </summary>
        public int idConsulta;
        public TipoConsulta tipoConsulta;
        protected int numSala;
        protected int diaConsulta;
        protected int mesConsulta;
        protected double horaConsulta;
        public int nifCliente;
        public int idDentista;

        private Dictionary<int, List<Consultas>> consultas = new Dictionary<int, List<Consultas>>();
        #endregion

        #region Metodos

        #region Construtores
        /// <summary>
        /// Construtores da class Consulta
        /// </summary>
        public Consultas()
        {
            
        }
        public Consultas(int idConsulta, TipoConsulta tipoConsulta, int numSala, int diaConsulta, int mesConsulta, double horaConsulta, int nifCliente, int idDentista)/* : base(nifCliente, idDentista)*/
        {
            this.idConsulta = idConsulta;
            this.tipoConsulta = tipoConsulta;
            this.numSala = numSala;
            this.diaConsulta = diaConsulta;
            this.mesConsulta = mesConsulta;
            this.horaConsulta = horaConsulta;
            this.nifCliente = nifCliente;
            this.idDentista = idDentista;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Consulta
        /// </summary>
        public int IdConsulta
        {
            get { return idConsulta; }
            set { idConsulta = value; }
        }
        public TipoConsulta Tipo
        {
            get { return tipoConsulta; }
            set { tipoConsulta = value; }
        }
        public int NumSala
        {
            get { return numSala; }
            set { numSala = value; }
        }
        public int DiaConsulta
        {
            get { return diaConsulta; }
            set {  diaConsulta = value; }
        }
        public int MesConsulta
        {
            get { return mesConsulta; }
            set { mesConsulta = value; }
        }
        public double HoraConsulta
        {
            get { return horaConsulta; }
            set { horaConsulta = value; }
        }
        public int NifCliente
        {
            get { return nifCliente; }
        }

        public int IdDentista
        {
            get { return idDentista; }
        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Override da class Consulta
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Consulta [ID: {idConsulta}, Tipo: {tipoConsulta}, Num. Sala: {numSala}, Data (dia/mes/hora): {diaConsulta} / {mesConsulta} / {horaConsulta}, NIF Cliente: {nifCliente}, ID Dentista: {idDentista}]";
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (ReferenceEquals(obj, null))
            {
                return false;
            }

            throw new NotImplementedException();
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region OutrosMetodos

        #region Operadores
        /// <summary>
        /// Operadores da class Consulta
        /// </summary>
        /// <param name="co1"></param>
        /// <param name="co2"></param>
        /// <returns></returns>
        public static bool operator ==(Consultas co1, Consultas co2)
        {
            if(co1 is null && co2 is null)
                return true;
            if (co1 is null || co2 is null)
                return false;

            return co1.idConsulta == co2.idConsulta && co1.tipoConsulta == co2.tipoConsulta && co1.numSala == co2.numSala && co1.diaConsulta == co2.diaConsulta
                   && co1.mesConsulta == co2.mesConsulta && co1.horaConsulta == co2.horaConsulta && co1.nifCliente == co2.nifCliente && co1.idDentista == co2.idDentista;
        }

        public static bool operator !=(Consultas co1, Consultas co2)
        {
            return !(co1 == co2);
        }
        #endregion

        #region Funcoes
        public void ConsultasClass()
        {
            consultas = new Dictionary<int, List<Consultas>>();
        }

        /// <summary>
        /// Funçao para inserir uma nova consulta
        /// </summary>
        /// <param name="idConsulta"></param>
        /// <param name="tipoConsulta"></param>
        /// <param name="numSala"></param>
        /// <param name="diaConsulta"></param>
        /// <param name="mesConsulta"></param>
        /// <param name="horaConsulta"></param>
        /// <param name="nifCliente"></param>
        /// <param name="idDentista"></param>
        /// <returns></returns>
        public bool InserirConsulta(int idConsulta, TipoConsulta tipoConsulta, int numSala, int diaConsulta, int mesConsulta, double horaConsulta, int nifCliente, int idDentista)
        {
            //Verifica se o id já existe no dicionário
            if (consultas.ContainsKey(idConsulta))
            {
                Console.WriteLine("ID ja existe");
                return false; //Retorna false, id já existe
            }

            //Cria um novo objeto Consulta com os dados fornecidos
            Consultas novaConsulta = new Consultas(idConsulta, tipoConsulta, numSala, diaConsulta, mesConsulta, horaConsulta, nifCliente, idDentista);

            //Adiciona a nova Consulta ao dicionário
            consultas.Add(idConsulta, new List<Consultas> { novaConsulta });

            return true; //Retorna true, inseriu com sucesso
        }

        /// <summary>
        /// Funçao para guardar as consultas em binário num ficheiro txt
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool GuardarConsultas(string nomeFicheiro)
        {
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream(nomeFicheiro, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    formatter.Serialize(stream, consultas);
                }
                return true;
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: " + e.Message);
                return false;
            }
        }

        /// <summary>
        /// Funçao para cancelar (remover) uma consulta a partir do seu id de consulta
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="idConsulta"></param>
        /// <returns></returns>
        public bool CancelarConsulta(string nomeFicheiro, int idConsulta)
        {
            Dictionary<int, List<Consultas>> consultas;

            try
            {
                using (Stream stream = File.Open(nomeFicheiro, FileMode.Open))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    consultas = (Dictionary<int, List<Consultas>>)formatter.Deserialize(stream);
                }

                if (consultas.ContainsKey(idConsulta))
                {
                    consultas.Remove(idConsulta);

                    using (Stream stream = File.Open(nomeFicheiro, FileMode.Create))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        formatter.Serialize(stream, consultas);
                    }
                    return true;
                }
                else { return false; }
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
        }

        /// <summary>
        /// Funçao para listar as consultas a partir do ficheiro consultas
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool ListarConsultas(string nomeFicheiro)
        {
            try
            {
                if (File.Exists(nomeFicheiro))
                {
                    byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                    using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        Consultas[] consultas = (Consultas[])formatter.Deserialize(memoryStream);
                        foreach (Consultas consulta in consultas)
                        {
                            Console.WriteLine($"ID: {idConsulta}, Tipo: {tipoConsulta}, Num. Sala: {numSala},Data (dia/mes/hora): {diaConsulta} / {mesConsulta} / {horaConsulta}, NIF Cliente: {nifCliente}, ID Dentista: {idDentista}");
                        }
                    }
                    return true;
                }
                else
                {
                    throw new FileNotFoundException("O ficheiro não existe");
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao ler o ficheiro. Por favor, verifique o caminho do ficheiro e tente novamente");
                return false;
            }
        }

        /// <summary>
        /// Funçao para procurar uma consulta pelo idConsulta
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="idConsulta"></param>
        /// <returns></returns>
        public bool ProcurarConsulta(string nomeFicheiro, int idConsulta)
        {
            if (File.Exists(nomeFicheiro))
            {
                byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Dictionary<int, List<Consultas>> consultas = (Dictionary<int, List<Consultas>>)formatter.Deserialize(memoryStream);
                    foreach (var consultaList in consultas.Values)
                    {
                        foreach (var consulta in consultaList)
                        {
                            if (consulta.idConsulta == idConsulta)
                            {
                                Console.WriteLine("Consulta encontrado");
                                Console.WriteLine($"ID: {idConsulta}, Tipo: {tipoConsulta}, Num. Sala: {numSala},Data (dia/mes/hora): {diaConsulta} / {mesConsulta} / {horaConsulta}, NIF Cliente: {nifCliente}, ID Dentista: {idDentista}");
                                return true;
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("O ficheiro nao existe");
            }

            Console.WriteLine("Consulta nao encontrado");
            return false;
        }
        #endregion

        #region Destrutor
        ~Consultas()
        {

        }
        #endregion

        #endregion
        #endregion
    }
}
