﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Material
 *   
 */
using Pessoa;
using System;
using System.Runtime.Serialization.Formatters.Binary;

#pragma warning disable SYSLIB0011 //BinaryFormatter indicado como obsoleto, suprimir esse erro

/// <summary>
/// Enum que define o tipo de material
/// </summary>
public enum TipoMaterial
{
    Regular,
    Cirurgico
}

namespace Consulta
{
    [Serializable]
    public class Material
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Material
        /// </summary>
        protected int numSerie;
        protected string nomeMat;
        protected int numSala;
        protected TipoMaterial tipoMat;

        private Dictionary<int, List<Material>> materiais = new Dictionary<int, List<Material>>();
        #endregion

        #region Metodos

        #region Construtores
        /// <summary>
        /// Contrutores da class Material
        /// </summary>
        public Material()
        {
            nomeMat = "";
            tipoMat = TipoMaterial.Regular;
        }
        public Material(int numSerie, string nomeMat, int numSala, TipoMaterial tipoMat)
        {
            this.numSerie = numSerie;
            this.nomeMat = nomeMat;
            this.numSala = numSala;
            this.tipoMat = tipoMat;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Material
        /// </summary>
        public int NumSerie
        {
            get { return numSerie; }
            set { numSerie = value; }
        }
        public string NomeMaterial
        {
            get { return nomeMat; }
            set { nomeMat = value; }

        }
        public int NumSala
        {
            get { return numSala; }
            set { numSala = value; }
        }

        public TipoMaterial Tipo
        {
            get { return tipoMat; }
            set { tipoMat = value; }

        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Overides da class Material
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Material =>Numero de Serie: {numSerie} - Nome do Material: {nomeMat} - Numero Sala: {numSala} - Tipo Material: {tipoMat}";
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (ReferenceEquals(obj, null))
            {
                return false;
            }

            throw new NotImplementedException();
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region OutrosMetodos

        #region Operadores
        /// <summary>
        /// Operadores da class Material
        /// </summary>
        public static bool operator ==(Material m1, Material m2)
        {
            if(m1 is null && m2 is null)
                return true;
            if (m1 is null || m2 is null)
                return false;

            return m1.numSerie == m2.numSerie && m1.nomeMat == m2.nomeMat && m1.numSala == m2.numSala && m1.tipoMat == m2.tipoMat;
        }

        public static bool operator !=(Material m1, Material m2)
        {
            return !(m1 == m2);
        }
        #endregion

        #region Funcoes
        public void MateriaisClass()
        {
            materiais = new Dictionary<int, List<Material>>();
        }

        /// <summary>
        /// Funçao para inserir os valores dos materiais
        /// </summary>
        /// <param name="numSerie"></param>
        /// <param name="nomeMat"></param>
        /// <param name="numSala"></param>
        /// <param name="tipoMat"></param>
        /// <returns></returns>
        public bool InserirMaterial(int numSerie, string nomeMat, int numSala, TipoMaterial tipoMat)
        {
            //Verifica se o numSerie já existe no dicionário
            if (materiais.ContainsKey(numSerie))
            {
                Console.WriteLine("Numero de serie ja existe");
                return false; //Retorna false, numSerie já existe
            }

            //Cria um novo objeto Material com os dados fornecidos
            Material novoMaterial = new Material(numSerie, nomeMat, numSala, tipoMat);

            //Adiciona o novo Material ao dicionário
            materiais.Add(numSerie, new List<Material> { novoMaterial });

            return true; //Retorna true, inseriu com sucesso
        }

        /// <summary>
        /// Funçao para guardar os Materiais em binário num ficheiro txt
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool GuardarMaterial(string nomeFicheiro)
        {
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream(nomeFicheiro, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    formatter.Serialize(stream, materiais);
                }
                return true;
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: " + e.Message);
                return false;
            }
        }

        /// <summary>
        /// Funçao para remover um material a partir do seu nummero de serie
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="numSerie"></param>
        /// <returns></returns>
        public bool RemoverMaterial(string nomeFicheiro, int numSerie)
        {
            Dictionary<int, List<Material>> materiais;

            try
            {
                using (Stream stream = File.Open(nomeFicheiro, FileMode.Open))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    materiais = (Dictionary<int, List<Material>>)formatter.Deserialize(stream);
                }

                if (materiais.ContainsKey(numSerie))
                {
                    materiais.Remove(numSerie);

                    using (Stream stream = File.Open(nomeFicheiro, FileMode.Create))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        formatter.Serialize(stream, materiais);
                    }
                    return true;
                }
                else { return false; }
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
        }

        /// <summary>
        /// Funçao para listar todos os materiais a partir do ficheiro materiais
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool ListarMaterial(string nomeFicheiro)
        {
            try
            {
                if (File.Exists(nomeFicheiro))
                {
                    byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                    using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        Material[] materiais = (Material[])formatter.Deserialize(memoryStream);
                        foreach (Material material in materiais)
                        {
                            Console.WriteLine($"Numero Serie: {material.numSerie}, Nome: {material.nomeMat}, Numero Sala: {material.numSala}, Tipo: {material.tipoMat}");
                        }
                    }
                    return true;
                }
                else
                {
                    throw new FileNotFoundException("O ficheiro não existe");
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao ler o ficheiro. Por favor, verifique o caminho do ficheiro e tente novamente");
                return false;
            }

        }

        /// <summary>
        /// Funçao para procurar um material especifico a partir do numero de serie
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="numSerie"></param>
        /// <returns></returns>
        public bool ProcurarMaterial(string nomeFicheiro, int numSerie)
        {
            if (File.Exists(nomeFicheiro))
            {
                byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Dictionary<int, List<Material>> materiais = (Dictionary<int, List<Material>>)formatter.Deserialize(memoryStream);
                    foreach (var materialList in materiais.Values)
                    {
                        foreach (var material in materialList)
                        {
                            if (material.numSerie == numSerie)
                            {
                                Console.WriteLine("Material encontrado");
                                Console.WriteLine($"Numero Serie: {material.numSerie}, Nome: {material.nomeMat}, Numero Sala: {material.numSala}, Tipo: {material.tipoMat}");
                                return true;
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("O ficheiro nao existe");
            }

            Console.WriteLine("Dentista nao encontrado");
            return false;
        }
        #endregion

        #region Destrutor
        ~Material()
        {

        }

        #endregion

        #endregion
        #endregion
    }
}
