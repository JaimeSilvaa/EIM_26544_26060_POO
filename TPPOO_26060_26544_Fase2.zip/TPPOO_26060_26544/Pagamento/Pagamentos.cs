﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Pagamentos que recorre as classes Cliente e Consulta para definir certos atributos
 *  
*/
using Pessoa;
using Consulta;
using System.Runtime.Serialization.Formatters.Binary;

#pragma warning disable SYSLIB0011 //BinaryFormatter indicado como obsoleto, suprimir esse erro

namespace Pagamento
{
    [Serializable]
    public class Pagamentos
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Pagamentos
        /// </summary>

        protected int idFatura;
        protected double valorCobrar;

        public double saldo;
        public int nifCliente;
        public int idConsulta;
        public TipoConsulta tipoConsulta;

        private Dictionary<int, List<Pagamentos>> pagamentos = new Dictionary<int, List<Pagamentos>>();
        #endregion

        #region Construtores
        public Pagamentos()
        {

        }
        /// <summary>
        /// Construtor da class Pagamentos
        /// </summary>
        /// <param name="idFatura"></param>
        /// <param name="valorCobrar"></param>
        /// <param name="nifCliente"></param>
        /// <param name="idConsulta"></param>
        /// <param name="tipoConsulta"></param>
        public Pagamentos(int idFatura, double valorCobrar, double saldo, int nifCliente, int idConsulta, TipoConsulta tipoConsulta)
        {
            this.idFatura = idFatura;
            this.valorCobrar = valorCobrar;
            this.saldo = saldo;
            this.nifCliente = nifCliente;
            this.idConsulta = idConsulta;
            this.tipoConsulta = tipoConsulta;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Pagamentos
        /// </summary>
        public int IdFatura
        {
            get { return idFatura; }
            set { idFatura = value; }
        }
        public double ValorCobrar
        {
            get { return valorCobrar; }
            set { valorCobrar = value; }
        }
        public double Saldo
        {
            get { return saldo; }
        }
        public int NifCliente
        {
            get { return nifCliente; }
        }
        public int IdConsulta
        {
            get { return idConsulta; }
        }
        public TipoConsulta Tipo
        {
            get { return tipoConsulta; }
        }
        #endregion

        # region Overrides
        /// <summary>
        /// Overrides da class Pagamentos
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Pagamento [ID Fatura: {idFatura}, Valor: {valorCobrar}, NIF: {nifCliente}, ID Consulta: {idConsulta}, Tipo de consulta: {tipoConsulta}]";
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (ReferenceEquals(obj, null))
            {
                return false;
            }

            throw new NotImplementedException();
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region OutrosMetodos

        #region Operadores
        /// <summary>
        /// Operadores da class Pagamentos
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        public static bool operator ==(Pagamentos p1, Pagamentos p2)
        {
            if (p1 is null && p2 is null)
                return true;
            if (p1 is null || p2 is null)
                return false;

            return p1.idFatura == p2.idFatura && p1.valorCobrar == p2.valorCobrar && p1.nifCliente == p2.nifCliente && p1.idConsulta == p2.idConsulta && p1.tipoConsulta == p2.tipoConsulta;
        }

        public static bool operator !=(Pagamentos p1, Pagamentos p2)
        {
            return !(p1 == p2);
        }
        #endregion

        #region Destrutor
        ~Pagamentos()
        {

        }
        #endregion

        #region Funcoes
        /// <summary>
        /// Funçao para representar os valores da class Cliente e Consultas na class Pagamentos
        /// </summary>
        /// <param name="c"></param>
        /// <param name="co"></param>
        /// <param name="p"></param>
        public static void AtribuirValores(Cliente c, Consultas co, Pagamentos p)
        {
            c.SaldoCliente = p.saldo;
            c.nifCliente = p.nifCliente;
            co.idConsulta = p.idConsulta;
            co.tipoConsulta = p.tipoConsulta;
        }

        /// <summary>
        /// Funçao para verificar se ja foi efetuado um pagamento e caso contrário adiciona o pagamento
        /// </summary>
        /// <param name="pagamento"></param>
        /// <returns></returns>
        public bool VerificarPagamento(Pagamentos pagamento)
        {
            if (pagamentos.ContainsKey(pagamento.idFatura))
            {
                Console.WriteLine("Ja foi cobrado");
                return false;
            }
            if (pagamentos.ContainsValue(new List<Pagamentos> { pagamento }))
            {
                pagamentos.Add(pagamento.IdFatura, new List<Pagamentos> { pagamento });
            }

            return true;
        }

        /// <summary>
        /// Cobra o valor do pagamento com base em cada tipo de consulta e verifica se o cliente tem saldo suficiente
        /// </summary>
        /// <param name="pagamento"></param>
        /// <param name="cliente"></param>
        /// <returns></returns>
        public bool CobrarValor(Pagamentos pagamento, Cliente cliente)
        {
            double valorPagamento = 0;
            
            switch (pagamento.tipoConsulta)
            {
                case TipoConsulta.Geral:
                    valorPagamento = 50;
                    break;
                case TipoConsulta.Ortodentia:
                    valorPagamento = 70;
                    break;
                case TipoConsulta.Exames:
                    valorPagamento = 65;
                    break;
            }
            if(valorPagamento > cliente.SaldoCliente)
            {
                Console.WriteLine("Saldo insuficiente");
                return false;
            }

            if (VerificarPagamento(pagamento))
            {
                cliente.SaldoCliente -= valorPagamento;
                Console.WriteLine("Pagamento efetuado com sucesso");
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// Funçao para guardar os pagamentos
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool GuardarPagamentos(string nomeFicheiro)
        {
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream(nomeFicheiro, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    formatter.Serialize(stream, pagamentos);
                }
                return true;
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: " + e.Message);
                return false;
            }
        }

        /// <summary>
        /// Funçao para listar os pagamentos
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool ListarPagamentos(string nomeFicheiro)
        {
            try
            {
                if (File.Exists(nomeFicheiro))
                {
                    byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                    using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        Cliente[] clientes = (Cliente[])formatter.Deserialize(memoryStream);
                        foreach (Cliente cliente in clientes)
                        {
                            Console.WriteLine($"ID Fatura: {idFatura}, Valor: {valorCobrar}, NIF: {nifCliente}, ID Consulta: {idConsulta}, Tipo de consulta: {tipoConsulta}");
                        }
                    }
                    return true;
                }
                else
                {
                    throw new FileNotFoundException("O ficheiro não existe");
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao ler o ficheiro. Por favor, verifique o caminho do ficheiro e tente novamente");
                return false;
            }
        }

        #endregion
        #endregion
    }
}
