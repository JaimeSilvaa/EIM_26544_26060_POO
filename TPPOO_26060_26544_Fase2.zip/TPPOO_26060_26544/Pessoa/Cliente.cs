﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Cliente que recorre a class Pessoa para definir certos atributos
 *  
*/
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;


#pragma warning disable SYSLIB0011 //BinaryFormatter indicado como obsoleto, suprimir esse erro

namespace Pessoa
{
    [Serializable] //significa que a class pode ser convertida numa sequencia de bytes
    public class Cliente : Pessoa
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Cliente nome e numTlm definidos na class Pessoa
        /// </summary>
        public int nifCliente;
        private int idade;
        private string moradaCliente = "";
        private double saldo;

        private Dictionary<int, List<Cliente>> clientes = new Dictionary<int, List<Cliente>>();
        #endregion

        #region Metodos

        #region Construtores
        public Cliente() { }

        /// <summary>
        /// Construtor da class Cliente, vai buscar os atributos nome e numtlm a class Pessoa
        /// </summary>
        /// <param name="nomeC"></param>
        /// <param name="numTlmC"></param>
        /// <param name="nifC"></param>
        /// <param name="idadeC"></param>
        /// <param name="moradaC"></param>
        /// <param name="saldo"></param>
        public Cliente(int nifCliente, string nome, int numTlm, int idade, string moradaCliente, double saldo) : base(nome, numTlm)
        {
            this.nifCliente = nifCliente;
            this.nome = nome;
            this.numTlm = numTlm;
            this.idade = idade;
            this.moradaCliente = moradaCliente;
            this.saldo = saldo;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Cliente
        /// </summary>
        public int NifCliente
        {
            get { return nifCliente; }
            set { nifCliente = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public int NumTlm
        {
            get { return numTlm; }
            set { numTlm = value; }
        }

        public int IdadeCliente
        {
            get { return idade; }
            set { idade = value; }
        }

        public string MoradaCliente
        {
            get { return moradaCliente; }
            set { moradaCliente = value; }
        }

        public double SaldoCliente
        {
            get { return saldo; }
            set { saldo = value; }
        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Serve para apresentar uma string costumizada que representa o objeto Cliente
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Cliente [NIF: {nifCliente}, Nome: {nome}, Num. Telemovel: {numTlm}, Idade: {idade}, Morada: {moradaCliente}, Saldo: {saldo}]";
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (ReferenceEquals(obj, null))
            {
                return false;
            }

            throw new NotImplementedException();
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }

        #endregion

        #region OutrosMetodos

        #region Operadores
        /// <summary>
        /// Operadores para class Cliente
        /// </summary>
        /// <param name="c1"></param>
        /// <param name="c2"></param>
        /// <returns></returns>
        public static bool operator ==(Cliente c1, Cliente c2)
        {
            if (c1 is null && c2 is null)
                return true;
            if (c1 is null || c2 is null)
                return false;

            return c1.nome == c2.nome && c1.numTlm == c2.numTlm && c1.nifCliente == c2.nifCliente
                        && c1.idade == c2.idade && c1.moradaCliente == c2.moradaCliente;
        }

        public static bool operator !=(Cliente c1, Cliente c2)
        {
            return !(c1 == c2);
        }
        #endregion

        #region Destrutor
        ~Cliente()
        {

        }
        #endregion

        #region Funcoes
        public void ClientesClass()
        {
            clientes = new Dictionary<int, List<Cliente>>();
        }

        //public void CarregarClientes(string nomeFicheiro)
        //{
        //    if (File.Exists(nomeFicheiro))
        //    {
        //        BinaryFormatter formatter = new BinaryFormatter();
        //        using(FileStream stream = new FileStream(nomeFicheiro, FileMode.Open, FileAccess.Read))
        //        {
        //            try
        //            {
        //                Dictionary<int, List<Cliente>> clientesCarregados = (Dictionary<int, List<Cliente>>)formatter.Deserialize(stream);
        //                foreach(var cliente in clientesCarregados)
        //                {
        //                    clientes[cliente.Key] = cliente.Value;
        //                }
        //            }
        //            catch (Exception e)
        //            {
        //                Console.WriteLine("Erro: " + e.Message);
        //            }
        //        }
        //    }
        //}

        /// <summary>
        /// Função para inserir um novo cliente
        /// </summary>
        /// <param name="nifCliente"></param>
        /// <param name="nome"></param>
        /// <param name="numTlm"></param>
        /// <param name="idade"></param>
        /// <param name="morada"></param>
        /// <param name="saldo"></param>
        /// <returns></returns>

        /// int nifCliente, string nome, int numTlm, int idade, string moradaCliente, double saldo
        public bool InserirCliente(Cliente cliente)
        {
            //Verifica se o nif já existe no dicionário
            if (clientes.ContainsKey(nifCliente))
            {
                Console.WriteLine("NIF ja existe");
                return false; //Retorna false, nif já existe
            }

            //Cria um novo objeto Cliente com os dados fornecidos
            Cliente novoCliente = new Cliente(nifCliente, nome, numTlm, idade, moradaCliente, saldo);

            //Adiciona o novo cliente ao dicionário
            clientes.Add(nifCliente, new List<Cliente> { novoCliente });

            return true; //Retorna true, inseriu com sucesso
        }

        /// <summary>
        /// Funçao para guardar os clientes em binário num ficheiro txt
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool GuardarClientes(string nomeFicheiro)
        {
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream(nomeFicheiro, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    formatter.Serialize(stream, clientes);
                }
                return true;
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: " + e.Message);
                return false;
            }
        }

        /// <summary>
        /// Funçao para remover um cliente a partir do seu nif
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="nif"></param>
        public bool RemoverCliente(string nomeFicheiro, int nif)
        {
            Dictionary<int, List<Cliente>> clientes;

            try
            {
                using (Stream stream = File.Open(nomeFicheiro, FileMode.Open))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    clientes = (Dictionary<int, List<Cliente>>)formatter.Deserialize(stream);
                }

                if (clientes.ContainsKey(nif))
                {
                    clientes.Remove(nif);

                    using (Stream stream = File.Open(nomeFicheiro, FileMode.OpenOrCreate))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        formatter.Serialize(stream, clientes);
                    }
                    return true;
                }
                else { return false; }
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
        }

        /// <summary>
        /// Funçao para listar todos os clientes a partir do ficheiro dos clientes
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        public bool ListarClientes(string nomeFicheiro)
        {
            try
            {
                if (File.Exists(nomeFicheiro))
                {
                    byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                    using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        Cliente[] clientes = (Cliente[])formatter.Deserialize(memoryStream);
                        foreach (Cliente cliente in clientes)
                        {
                            Console.WriteLine($"NIF: {cliente.nifCliente}, Nome: {cliente.nome}, NumTlm: {cliente.numTlm}, Idade: {cliente.idade},  Morada: {cliente.moradaCliente}, Saldo: {cliente.saldo}");
                        }
                    }
                    return true;
                }
                else
                {
                    throw new FileNotFoundException("O ficheiro não existe");
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao ler o ficheiro. Por favor, verifique o caminho do ficheiro e tente novamente");
                return false;
            }
        }

        /// <summary>
        /// Funcao para procurar um cliente especifico a partir do NIF
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="Cliente"></param>
        public bool ProcurarCliente(string nomeFicheiro, int nifCliente)
        {
            if (File.Exists(nomeFicheiro))
            {
                byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Dictionary<int, List<Cliente>> clientes = (Dictionary<int, List<Cliente>>)formatter.Deserialize(memoryStream);
                    foreach (var clienteList in clientes.Values)
                    {
                        foreach (var cliente in clienteList)
                        {
                            if (cliente.nifCliente == nifCliente)
                            {
                                Console.WriteLine("Cliente encontrado");
                                Console.WriteLine($"NIF: {cliente.nifCliente}, Nome: {cliente.nome}, NumTlm: {cliente.numTlm}, Idade: {cliente.idade}, Morada: {cliente.moradaCliente}, Saldo: {cliente.saldo}");
                                return true;
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("O ficheiro nao existe");
            }

            Console.WriteLine("Cliente nao encontrado");
            return false;
        }

        #endregion

        #region Validacao
        public static bool ValidaIdade(int idade)
        {
            return (idade > 3 && idade < 120);
        }

        #endregion

        #endregion
        #endregion
    }
}
