﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Dentista que recorre a class Pessoa para definir certos atributos
 *  
 */
using System.Runtime.Serialization.Formatters.Binary;

#pragma warning disable SYSLIB0011 //BinaryFormatter indicado como obsoleto, suprimir esse erro

public enum EspecialidadeDentista
{
    Ortodentista,
    ClinicoGeral
}

namespace Pessoa
{
    [Serializable]
    public class Dentista : Pessoa
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Dentista,tipoPessoa, nome e numTlm definidos na class Pessoa
        /// </summary>
        public int idDentista;
        protected EspecialidadeDentista especialidade;

        private Dictionary<int, List<Dentista>> dentistas = new Dictionary<int, List<Dentista>>();
        #endregion

        #region Metodos

        #region Construtores
        public Dentista() { }

        /// <summary>
        /// Construtor da class Dentista, vai buscar os atributos nome e numtlm a class Pessoa
        /// </summary>
        /// <param name="idD"></param>
        /// <param name="nome"></param>
        /// <param name="numTlm"></param>
        /// <param name="e"></param>
        public Dentista(int idD, string nome, int numTlm, EspecialidadeDentista e) : base(nome, numTlm)
        {
            idDentista = idD++;
            especialidade = e;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Dentista
        /// </summary>
        public int IdDentista
        {
            set { idDentista = value; }
            get { return idDentista; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public int NumTlm
        {
            get { return numTlm; }
            set { numTlm = value; }
        }

        public EspecialidadeDentista Especialidade
        {
            set { especialidade = value; }
            get { return especialidade; }
        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Override da class Dentista
        /// </summary>
        public override string ToString()
        {
            return $"Dentista [ID: {idDentista}, Nome: {nome}, Num. Telemovel: {numTlm}, Especialidade: {especialidade}]";
        }
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (ReferenceEquals(obj, null))
            {
                return false;
            }

            throw new NotImplementedException();
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region OutrosMetodos

        #region Operadores
        /// <summary>
        /// Operadores para class Dentista
        /// </summary>
        /// <param name="d1"></param>
        /// <param name="d2"></param>
        /// <returns></returns>
        public static bool operator ==(Dentista d1, Dentista d2)
        {
            if (d1 is null && d2 is null)
                return true;
            if (d1 is null || d2 is null)
                return false;

            return d1.nome == d2.nome && d1.idDentista == d2.idDentista
                   && d1.numTlm == d2.numTlm && d1.especialidade == d2.especialidade;
        }

        public static bool operator !=(Dentista d1, Dentista d2)
        {
            return !(d1 == d2);
        }
        #endregion

        #region Funcoes
        public void DentistasClass()
        {
            dentistas = new Dictionary<int, List<Dentista>>();
        }


        /// <summary>
        /// Função para inserir os valores dos dentistas
        /// </summary>
        /// <param name="idDentista"></param>
        /// <param name="nome"></param>
        /// <param name="numTlm"></param>
        /// <param name="especialidade"></param>
        /// <returns></returns>
        public bool InserirDentista(int idDentista, string nome, int numTlm, EspecialidadeDentista especialidade)
        {
            //Verifica se o id já existe no dicionário
            if (dentistas.ContainsKey(idDentista))
            {
                Console.WriteLine("ID ja existe");
                return false; //Retorna false, id já existe
            }

            //Cria um novo objeto Dentista com os dados fornecidos
            Dentista novoDentista = new Dentista(idDentista, nome, numTlm, especialidade);

            //Adiciona o novo dentista ao dicionário
            dentistas.Add(idDentista, new List<Dentista> { novoDentista });

            return true; //Retorna true, inseriu com sucesso
        }

        /// <summary>
        /// Funçao para guardar os dentistas em binário num ficheiro txt
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <returns></returns>
        public bool GuardarDentistas(string nomeFicheiro)
        {
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream(nomeFicheiro, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    formatter.Serialize(stream, dentistas);
                }
                return true;
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: " + e.Message);
                return false;
            }
        }

        /// <summary>
        /// Funçao para remover um dentista a partir do seu id
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="id"></param>
        public bool RemoverDentista(string nomeFicheiro, int id)
        {
            Dictionary<int, List<Dentista>> Dentistas;

            try
            {
                using (Stream stream = File.Open(nomeFicheiro, FileMode.Open))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Dentistas = (Dictionary<int, List<Dentista>>)formatter.Deserialize(stream);
                }

                if (Dentistas.ContainsKey(id))
                {
                    Dentistas.Remove(id);

                    using (Stream stream = File.Open(nomeFicheiro, FileMode.Create))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        formatter.Serialize(stream, Dentistas);
                    }
                    return true;
                }
                else { return false; }
            }
            catch (IOException e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro: {e}", e.Message);
                throw;
            }
        }


        /// <summary>
        /// Funçao para listar todos os dentistas a partir do ficheiro dos dentistas
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        public bool ListarDentistas(string nomeFicheiro)
        {
            try
            {
                if (File.Exists(nomeFicheiro))
                {
                    byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                    using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        Dentista[] dentistas = (Dentista[])formatter.Deserialize(memoryStream);
                        foreach (Dentista dentista in dentistas)
                        {
                            Console.WriteLine($"Id: {dentista.idDentista}, Nome: {dentista.nome}, NumTlm: {dentista.numTlm}, Especialidade: {dentista.especialidade}");
                        }
                    }
                    return true;
                }
                else
                {
                    throw new FileNotFoundException("O ficheiro não existe");
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao ler o ficheiro. Por favor, verifique o caminho do ficheiro e tente novamente");
                return false;
            }

        }

        /// <summary>
        /// Funcao para procurar um dentista especifico a partir do id
        /// </summary>
        /// <param name="nomeFicheiro"></param>
        /// <param name="idDentista"></param>
        public bool ProcurarDentista(string nomeFicheiro, int idDentista)
        {
            if (File.Exists(nomeFicheiro))
            {
                byte[] dadosBin = File.ReadAllBytes(nomeFicheiro);
                using (MemoryStream memoryStream = new MemoryStream(dadosBin))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Dictionary<int, List<Dentista>> dentistas = (Dictionary<int, List<Dentista>>)formatter.Deserialize(memoryStream);
                    foreach (var dentistaList in dentistas.Values)
                    {
                        foreach (var dentista in dentistaList)
                        {
                            if (dentista.idDentista == idDentista)
                            {
                                Console.WriteLine("Dentista encontrado");
                                Console.WriteLine($"Id: {dentista.idDentista}, Nome: {dentista.nome}, NumTlm: {dentista.numTlm}, Especialidade: {dentista.especialidade}");
                                return true;
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("O ficheiro nao existe");
            }

            Console.WriteLine("Dentista nao encontrado");
            return false;
        }

        #endregion

        #region Destrutor
        ~Dentista()
        {

        }

        #endregion

        #endregion
        #endregion
    }
}
