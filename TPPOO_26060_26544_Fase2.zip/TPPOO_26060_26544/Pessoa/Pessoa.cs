﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Pessoa que define certos atributos da classes Cliente e Dentista
 *  
 */
namespace Pessoa
{
    public class Pessoa
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Pessoa
        /// </summary>

        protected string nome;
        protected int numTlm;

        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Pessoa
        /// </summary>
        public string NomePessoa
        {
            set { nome = value; }
            get { return nome; }
        }

        public int NumTlm
        {
            set { numTlm = value; }
            get { return numTlm; }
        }
        #endregion

        #region Construtores
        /// <summary>
        /// Construtores para a class Pessoa
        /// </summary>
        public Pessoa() { }

        public Pessoa(string nome, int numTlm)
        {
            this.nome = nome;
            this.numTlm = numTlm;
        }

        #endregion

        #region Validacoes
        /// <summary>
        /// Validaçao para o tamanho do nome
        /// </summary>
        /// <param name="nome"></param>
        /// <returns></returns>
        public static bool NomeTamanho(string nome)
        {
            //verifica se o nome tem um tamanho entre 1 e 30 caracteres
            return !string.IsNullOrEmpty(nome) && nome.Length <= 30;
        }

        /// <summary>
        /// Validaçao para o tamanho do numero de telemovel
        /// </summary>
        /// <param name="numero"></param>
        /// <returns></returns>
        public static bool NumeroTamanho(int numero)
        {
            string num = Convert.ToString(numero);
            return !string.IsNullOrEmpty(num) && num.Length == 9;
        }
        #endregion
    }
}
