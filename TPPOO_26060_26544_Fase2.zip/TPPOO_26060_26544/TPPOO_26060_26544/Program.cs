﻿/*
* Author: Jaime Silva e Carolina Cruz
* N aluno:26544 e 26060
* Date: 04-11-2023
* 
* File: Class Program, local onde vai ser executado o programa
*  
*/
using System;
using System.Collections.Generic;
using Pessoa;
using Consulta;
using Pagamento;

namespace TPPOO_26060_26544
{
    public class Program
    {
        static void Main(string[] args)
        {
            #region Cliente
            Cliente cliente = new Cliente(); //nova instancia de Cliente

            bool inserir =  cliente.InserirCliente(new Cliente(246925655, "Jaime Silva", 935478457, 20, "Rua da Silva, 123", 1760.30));
            if (inserir)
            {
                Console.WriteLine("Cliente inserido com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir cliente");
            }
            inserir = cliente.InserirCliente(new Cliente(556529642, "Carolina Cruz", 754874539, 19, "Rua da Coutada, 321", 2650.50));
            if (inserir)
            {
                Console.WriteLine("Cliente inserido com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir cliente");
            }

            bool guardar = cliente.GuardarClientes(@"c:\temp\clientes.txt");
            if (guardar)
            {
                Console.WriteLine("Cliente guardado com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao guardar cliente");
            }

            bool remover = cliente.RemoverCliente(@"c:\temp\clientes.txt", 246925655);
            if (remover)
            {
                Console.WriteLine("Cliente removido com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao remover cliente");
            }

            cliente.ListarClientes(@"c:\temp\clientes.txt");

            cliente.ProcurarCliente(@"c:\temp\clientes.txt", 246925655);
            #endregion

            #region Dentista
            Dentista dentista = new Dentista(); //nova instancia de Dentista

            inserir = dentista.InserirDentista(1, "Joao Vitor", 123456789, EspecialidadeDentista.ClinicoGeral);
            if (inserir)
            {
                Console.WriteLine("Dentista inserido com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir dentista");
            }
            inserir = dentista.InserirDentista(2, "Lara Vitor", 987654321, EspecialidadeDentista.Ortodentista);
            if (inserir)
            {
                Console.WriteLine("Dentista inserido com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir dentista");
            }

            guardar = dentista.GuardarDentistas(@"c:\temp\dentistas.txt");
            if (guardar)
            {
                Console.WriteLine("Dentista guardado com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao guardar dentista");
            }

            remover = dentista.RemoverDentista(@"c:\temp\dentistas.txt", 1);
            if (remover)
            {
                Console.WriteLine("Dentista removido com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao remover dentista");
            }

            dentista.ListarDentistas(@"c:\temp\dentistas.txt");

            dentista.ProcurarDentista(@"c:\temp\dentistas.txt", 2);

            #endregion

            #region Material
            Material material = new Material(); //nova instancia de Material

            inserir = material.InserirMaterial(1, "Bisturi", 3, TipoMaterial.Cirurgico);
            if (inserir)
            {
                Console.WriteLine("Material inserido com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir material");
            }
            inserir = material.InserirMaterial(2, "Sonda exploradora", 2, TipoMaterial.Regular);
            if (inserir)
            {
                Console.WriteLine("Material inserido com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir material");
            }

            guardar = material.GuardarMaterial(@"c:\temp\material.txt");
            if (guardar)
            {
                Console.WriteLine("Material guardado com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao guardar material");
            }

            remover = material.RemoverMaterial(@"c:\temp\material.txt", 1);
            if (remover)
            {
                Console.WriteLine("Material removido com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao remover material");
            }

            material.ListarMaterial(@"c:\temp\material.txt");

            material.ProcurarMaterial(@"c:\temp\material.txt", 2);

            #endregion

            #region Consulta
            Consultas consulta = new Consultas(); //nova instancia de Consultas

            inserir = consulta.InserirConsulta(1, TipoConsulta.Geral, 2, 20, 5, 15.30, 246925655, 1);
            if (inserir)
            {
                Console.WriteLine("Consulta inserida com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir consulta");
            }
            inserir = consulta.InserirConsulta(3, TipoConsulta.Ortodentia, 4, 15, 10, 16.30, 556529642, 2);
            if (inserir)
            {
                Console.WriteLine("Consulta inserida com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao inserir consulta");
            }

            guardar = consulta.GuardarConsultas(@"c:\temp\consultas.txt");
            if (guardar)
            {
                Console.WriteLine("Consulta guardado com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao guardar consulta");
            }

            remover = consulta.CancelarConsulta(@"c:\temp\consultas.txt", 1);
            if (remover)
            {
                Console.WriteLine("Consulta cancelada com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao cancelar consulta");
            }

            consulta.ListarConsultas(@"c:\temp\consultas.txt");

            consulta.ProcurarConsulta(@"c:\temp\consultas.txt", 2);

            #endregion

            #region Pagamento
            Pagamentos pagamento = new Pagamentos(); //nova instancia de Pagamentos

            bool cobrar = pagamento.CobrarValor(pagamento, cliente);
            if (cobrar)
            {
                Console.WriteLine("Pagamento realizado com sucesso");
            }
            else
            {
                Console.WriteLine("Falha ao realizar o pagamento");
            }

            guardar = pagamento.GuardarPagamentos(@"c:\temp\pagamentos.txt");
            if (guardar)
            {
                Console.WriteLine("Pagamentos guardados com sucesso");
            }
            else
            {
                Console.WriteLine("Erro ao guardar pagamentos");
            }

            pagamento.ListarPagamentos(@"c:\temp\pagamentos.txt");
            #endregion
        }
    }
}
