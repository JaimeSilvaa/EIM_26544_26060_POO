﻿using System;

namespace Pessoa
{
    public class Cliente
    {
        #region Atributos
        private string nomeCliente;
        private int nifCliente;
        private int idade;
        private int numTlm;
        private string moradaCliente;
        #endregion

        #region Metodos

        #region Construtores
        public Cliente()
        {
            nomeCliente = "";
            moradaCliente = "";

        }
        public Cliente(string nomeC, int nifC, int idadeC, int telemovelC, string moradaC)
        {
            nomeCliente = nomeC;
            nifCliente = nifC;
            idade = idadeC;
            numTlm = telemovelC;
            moradaCliente = moradaC;
        }
        #endregion

        #region Propriedades
        public string NomeCliente
        {
            set { nomeCliente = value; }
            get { return nomeCliente; }
        }

        public int NifCliente
        {
            set { nifCliente = value; }
            get { return nifCliente; }
        }

        public int IdadeCliente
        {
            set { idade = value; }
            get { return idade; }
        }

        public int NumTlmCliente
        {
            set { numTlm = value; }
            get { return numTlm; }
        }

        public string MoradaCliente
        {
            set { moradaCliente = value;}
            get { return moradaCliente; }
        }

        #endregion

        #region Overrides 
        public override string ToString()
        {
            return String.Format("Ficha de Cliente => Nome: {0} - NIF: {1} - Idade: {2} - NumeroTlm: {3} - Morada: {4}\n", nomeCliente, nifCliente, idade, numTlm, moradaCliente);
            //return base.ToString();
        }

        public override bool Equals(object obj)
        {
            Cliente aux = (Cliente)obj;
            if (this.nomeCliente == aux.nomeCliente && this.nifCliente == aux.nifCliente && this.idade == aux.idade && this.numTlm == aux.numTlm && this.moradaCliente == aux.moradaCliente) return true;
            return false;
            //return base.Equals(obj);
        }
        #endregion

        

        #region OutrosMetodos

        #region Operadores
        public static bool operator ==(Cliente c1, Cliente c2)
        {
            if(!(c1 is null) && !(c2 is null))
                if(c1.nomeCliente==c2.nomeCliente&&c1.nifCliente==c2.nifCliente&&c1.idade==c2.idade&&c1.numTlm==c2.numTlm&&c1.moradaCliente ==c2.moradaCliente) return true;
            return false;
        }

        public static bool operator !=(Cliente c1, Cliente c2)
        {
            return !(c1 == c2);
        }
        #endregion

        #region Destrutor
        ~Cliente(){

        }
        #endregion

        //definir metodos para inserir, guardar, listar e alterar

        #endregion

        
        #endregion

    }
}