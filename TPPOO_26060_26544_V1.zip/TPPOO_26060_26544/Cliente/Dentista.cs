﻿using System;

public enum EspecialidadeDentista
{
    Ortodentista,
    ClinicoGeral
}
namespace Pessoa
{
    public class Dentista
    {
        #region Atributos
        private string nomeDentista;
        private int idDentista;
        private int numTlm;
        private EspecialidadeDentista especialidade;
        #endregion

        #region Metodos
        #region Construtores
        public Dentista()
        {
            nomeDentista = "";
            especialidade = EspecialidadeDentista.Ortodentista;
        }
        public Dentista(string nomeD, int idD, int telemovelD, EspecialidadeDentista e)
        {
            this.nomeDentista = nomeD;
            this.idDentista = idD;
            this.numTlm = telemovelD;
            especialidade = e;
        }
        #endregion

        #region Propriedades
        public string NomeDentista
        {
            set { nomeDentista = value; }
            get { return nomeDentista; }
        }

        public int IdDentista
        {
            set { idDentista = value; }
            get { return idDentista; }
        }

        public int NumTlmDentista
        {
            set { numTlm = value; }
            get { return numTlm; }
        }

        public EspecialidadeDentista Especialidade
        {
            set { especialidade = value; }
            get { return especialidade; }
        }

        #endregion

        #region Overrides 
        public override string ToString()
        {
            return String.Format("Dentista => Nome: {0} - Id: {1} - NumeroTlm: {2} - Especialidade: {3} \n", nomeDentista, idDentista, numTlm, numTlm, especialidade);
            //return base.ToString();
        }

        public override bool Equals(object obj)
        {
            Dentista aux = (Dentista)obj;
            if (this.nomeDentista == aux.nomeDentista && this.idDentista == aux.idDentista && this.numTlm == aux.numTlm && this.especialidade == aux.especialidade) return true;
            return false;
            //return base.Equals(obj);
        }
        #endregion

        #region Operadores
        public static bool operator ==(Dentista d1, Dentista d2)
        {
            if (!(d1 is null) && !(d2 is null))
                if (d1.nomeDentista == d2.nomeDentista && d1.idDentista == d2.idDentista && d1.numTlm == d2.numTlm && d1.especialidade == d2.especialidade) return true;
            return false;
        }

        public static bool operator !=(Dentista d1, Dentista d2)
        {
            return !(d1 == d2);
        }
        #endregion

        #region Destrutor
        ~Dentista()
        {

        }
        #endregion
        #endregion
    }
}
