﻿namespace Pagamento
{
    public class Pagamento
    {

    }
}