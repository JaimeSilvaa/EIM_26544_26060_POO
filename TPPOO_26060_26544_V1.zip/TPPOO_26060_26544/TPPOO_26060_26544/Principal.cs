﻿using System;

namespace TPPOO_26060_26544
{
    public class Principal
    {
        static void Main(string[] args)
        {
        }
    }
}
