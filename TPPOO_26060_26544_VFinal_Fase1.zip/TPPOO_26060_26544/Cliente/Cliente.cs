﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Cliente que recorre a class Pessoa para definir certos atributos
 *  
 */
using System;
using Pessoa;

namespace Pessoa
{
    class Cliente : Pessoa
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Cliente, nome e numTlm definidos na class Pessoa
        /// </summary>
        private int nifCliente;
        private int idade;
        private string moradaCliente;
        #endregion

        #region Metodos

        #region Construtores
        /// <summary>
        /// Construtor da class Cliente, vai buscar os atributos nome e numtlm a class Pessoa
        /// </summary>
        /// <param name="nifC"></param>
        /// <param name="idadeC"></param>
        /// <param name="moradaC"></param>
        public Cliente(string nomeP,int numTlmP, int nifC, int idadeC, string moradaC) : base(nomeP, numTlmP)
        {

            nifCliente = nifC;
            idade = idadeC;
            moradaCliente = moradaC;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Cliente
        /// </summary>
        public int NifCliente
        {
            set { nifCliente = value; }
            get { return nifCliente; }
        }

        public int IdadeCliente
        {
            set { idade = value; }
            get { return idade; }
        }

        public string MoradaCliente
        {
            set { moradaCliente = value;}
            get { return moradaCliente; }
        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Override para apresentar os dados do Cliente
        /// </summary>
        public override void ApresentarPessoa()
        {
            base.ApresentarPessoa();
            Console.WriteLine(" | NIF: {0}   | Idade: {1}  | Morada: {2}",nifCliente,idade,moradaCliente);
        }

        #endregion

        #region OutrosMetodos

        #region Operadores
        /// <summary>
        /// Operadores para class Cliente, corrigir posteriormente
        /// </summary>
        /// <param name="c1"></param>
        /// <param name="c2"></param>
        /// <returns></returns>
        public static bool operator ==(Cliente c1, Cliente c2)
        {
            if(!(c1 is null) && !(c2 is null))
                if(c1.nomeP==c2.nomeP && c1.numTlmP==c2.numTlmP && c1.nifCliente==c2.nifCliente
                    && c1.idade==c2.idade && c1.moradaCliente ==c2.moradaCliente) 
                    return true;
            return false;
        }

        public static bool operator !=(Cliente c1, Cliente c2)
        {
            return !(c1 == c2);
        }
        #endregion

        #region Destrutor
        ~Cliente(){

        }
        #endregion

        //definir metodos para inserir, guardar, listar, alterar, etc.

        #endregion

        
        #endregion

    }
}