﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Dentista que recorre a class Pessoa para definir certos atributos
 *  
 */
using System;
using Pessoa;
using static System.Net.Mime.MediaTypeNames;

public enum EspecialidadeDentista
{
    Ortodentista,
    ClinicoGeral
}
namespace Pessoa
{
    public class Dentista : Pessoa
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Dentista, nome e numTlm definidos na class Pessoa
        /// </summary>
        private int idDentista;
        private EspecialidadeDentista especialidade;
        #endregion

        #region Metodos
        #region Construtores
        /// <summary>
        /// Construtor da class Dentista, vai buscar os atributos nome e numtlm a class Pessoa
        /// </summary>
        /// <param name="nomeP"></param>
        /// <param name="idD"></param>
        /// <param name="numTlmP"></param>
        /// <param name="e"></param>
        public Dentista(string nomeP, int idD, int numTlmP, EspecialidadeDentista e) : base(nomeP,numTlmP)
        {
            idDentista = idD;
            especialidade = e;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Dentista
        /// </summary>
        public int IdDentista
        {
            set { idDentista = value; }
            get { return idDentista; }
        }

        public EspecialidadeDentista Especialidade
        {
            set { especialidade = value; }
            get { return especialidade; }
        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Override da class Dentista
        /// </summary>
        public override void ApresentarPessoa()
        {
            base.ApresentarPessoa();
            Console.WriteLine(" | ID: {0}   | Especialidade: {1} \n", idDentista, especialidade);
        }
        #endregion

        #region OutrosMetodos
        #region Operadores
        /// <summary>
        /// Operadores para class Dentista, corrigir posteriormente
        /// </summary>
        /// <param name="d1"></param>
        /// <param name="d2"></param>
        /// <returns></returns>
        public static bool operator ==(Dentista d1, Dentista d2)
        {
            if (!(d1 is null) && !(d2 is null))
                if (d1.nomeDentista == d2.nomeDentista && d1.idDentista == d2.idDentista && d1.numTlm == d2.numTlm && d1.especialidade == d2.especialidade) return true;
            return false;
        }

        public static bool operator !=(Dentista d1, Dentista d2)
        {
            return !(d1 == d2);
        }
        #endregion

        //definir aqui funções para inserir, guardar, listar, etc.

        #region Destrutor
        ~Dentista()
        {

        }
        #endregion
        #endregion
        #endregion
    }
}
