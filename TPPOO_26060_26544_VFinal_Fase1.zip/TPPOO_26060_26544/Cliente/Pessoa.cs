﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Pessoa que define certos atributos da classes Cliente e Dentista
 *  
 */
using System;

namespace Pessoa
{
    class Pessoa
    {
        #region Atributos | Properties
        /// <summary>
        /// Atributos definidos e propriedades dos mesmos
        /// </summary>

        public string nome { get; set; }
        public int numTlm {  get; set; }

        #endregion

        #region Construtores
        /// <summary>
        /// Construtor para a class Pessoa
        /// </summary>
        /// <param name="nomeP"></param>
        /// <param name="numTlmP"></param>
        public Pessoa(string nomeP, int numTlmP) {

            nome = nomeP;
            numTlm = numTlmP;
        }

        #endregion

        #region Metodos
        /// <summary>
        /// Metodo para apresntar informação do nome e numero de telemovel
        /// </summary>
        public virtual void ApresentarPessoa()
        {
            Console.WriteLine("Nome: {0}   | NumTlm: {1} |  ", nome, numTlm);
        }

        #endregion
    }
}
