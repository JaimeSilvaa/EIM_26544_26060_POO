﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 04-11-2023
 * 
 * File: Class Consulta
 *  
 */
using System;
using Material;

namespace Consulta
{
    public class Consulta
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Consulta
        /// </summary>
        private int numSala;
        DateTime dataConsulta; //ano,mes, dia, hora, minuto, segundo (pela respetiva ordem)
        private int nifCliente;
        private int idDentista;
        #endregion

        #region Metodos

        #region Construtores
        /// <summary>
        /// Construtores da class Consulta
        /// </summary>
        public Consulta()
        {
            dataConsulta = DateTime.MinValue;

        }
        public Consulta(int numS, int nifC, int idD)
        {
            numSala = numS;
            dataConsulta = DateTime.MinValue;
            nifCliente = nifC;
            idDentista = idD;
        }

        public Consulta(int numS, DateTime dc, int nifC, int idD)
        {
            this.numSala = numS;
            dataConsulta = dc;
            this.nifCliente = nifC;
            this.idDentista = idD;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Consulta
        /// </summary>
        public int NumSala
        {
            set { numSala = value; }
            get { return numSala; }
        }

        public int NifCliente
        {
            set { nifCliente = value; }
            get { return nifCliente; }
        }

        public int IdDentista
        {
            set { idDentista = value; }
            get { return idDentista; }
        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Overrides da class Consulta
        /// </summary>
        /// <returns></returns>
        /*public override string ToString()
        {
            return String.Format("Consulta => Numero Sala: {0} - NIF Cliente: {1} - Id Dentista: {2}\n", numSala, nifCliente, idDentista);
            //return base.ToString();
        }

        public override bool Equals(object obj)
        {
            Consulta aux = (Consulta)obj;
            if (this.numSala == aux.numSala && this.nifCliente == aux.nifCliente && this.idDentista == aux.idDentista) return true;
            return false;
            //return base.Equals(obj);
        }*/
        #endregion

        #region OutrosMetodos
        #region Operadores
        /// <summary>
        /// Operadores da class Consulta
        /// </summary>
        public static bool operator ==(Consulta c1, Consulta c2)
        {
            if (!(c1 is null) && !(c2 is null))
                if (c1.numSala == c2.numSala && c1.nifCliente == c2.nifCliente && c1.idDentista == c2.idDentista) return true;
            return false;
        }

        public static bool operator !=(Consulta c1, Consulta c2)
        {
            return !(c1 == c2);
        }
        #endregion

        //recorrer a class Material para funções
        //definir funçõe para inserir, listar, etc.

        #region Destrutor
        ~Consulta()
        {

        }
        #endregion
        #endregion
        #endregion
    }
}