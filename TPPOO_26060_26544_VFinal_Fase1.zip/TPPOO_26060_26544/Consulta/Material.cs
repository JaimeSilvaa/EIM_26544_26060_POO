﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 14-11-2023
 * 
 * File: Class Material
 *   
 */
using System;

/// <summary>
/// Enum que define o tipo de material
/// </summary>
public enum TipoMaterial
{
    Regular,
    Cirurgico
}

namespace Consulta
{
    public class Material
    {
        #region Atributos
        /// <summary>
        /// Atributos da class Material
        /// </summary>
        private string nomeMat;
        private int numSala;
        private TipoMaterial tipoMat;

        #endregion

        #region Metodos

        #region Construtores
        /// <summary>
        /// Contrutores da class Material
        /// </summary>
        public Material()
        {
            nomeMat = "";
            tipoMat = TipoMaterial.Regular;
        }
        public Material(string nomeM, int numS, TipoMaterial t)
        {
            nomeMat = nomeM;
            numSala = numS;
            tipoMat = t;
        }
        #endregion

        #region Propriedades
        /// <summary>
        /// Propriedades da class Material
        /// </summary>
        public string NomeMaterial
        {
            set { nomeMat = value; }
            get { return nomeMat; }

        }
        public int NumSala
        {
            set { numSala = value; }
            get { return numSala; }
        }

        public TipoMaterial Tipo
        {
            set { tipoMat = value; }
            get { return tipoMat; }

        }

        #endregion

        #region Overrides 
        /// <summary>
        /// Overides da class Material
        /// </summary>
        /// <returns></returns>
        /*public override string ToString()
        {
            return String.Format("Material => Nome do Material: {0} - Numero Sala: {1} - Tipo Material: {2}\n",nomeMat, numSala, tipoMat);
            //return base.ToString();
        }

        public override bool Equals(object obj)
        {
            Material aux = (Material)obj;
            if (this.nomeMat == aux.nomeMat && this.numSala == aux.numSala && this.tipoMat == aux.tipoMat) return true;
            return false;
            //return base.Equals(obj);
        }*/
        #endregion

        #region OutrosMetodos
        #region Operadores
        /// <summary>
        /// Operadores da class Material
        /// </summary>
        public static bool operator ==(Material m1, Material m2)
        {
            if (!(m1 is null) && !(m2 is null))
                if (m1.nomeMat == m2.nomeMat && m1.numSala == m2.numSala && m1.tipoMat == m2.tipoMat) return true;
            return false;
        }

        public static bool operator !=(Material m1, Material m2)
        {
            return !(m1 == m2);
        }
        #endregion

        //criar funções para serem utilizadas na class Consulta
        //definir funções para inserir, listar, etc.

        #region Destrutor
        ~Material()
        {

        }
        #endregion
        #endregion
        #endregion
    }
}
