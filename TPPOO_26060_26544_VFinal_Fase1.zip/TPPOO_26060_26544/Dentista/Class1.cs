﻿namespace Dentista
{
    public class Class1
    {

    }
}