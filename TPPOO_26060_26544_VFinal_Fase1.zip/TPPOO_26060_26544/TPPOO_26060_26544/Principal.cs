﻿/*
 * Author: Jaime Silva e Carolina Cruz
 * N aluno:26544 e 26060
 * Date: 04-11-2023
 * 
 * File: Class Principal, local onde vai ser executado o programa
 *  
 */
using System;
using Consulta;
using Cliente;
using Dentista;
using Pagamento;

namespace TPPOO_26060_26544
{
    public class Principal
    {
        static void Main(string[] args)
        {
            //Colocar aqui WriteLines e chamar funções das diversas dll
        }
    }
}
